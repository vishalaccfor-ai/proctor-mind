from pathlib import Path
from dotenv import load_dotenv
from supabase import create_client
import json
from tqdm import tqdm
import os
import json
from config import (
    supabase,
    QUESTION_BANK,
)

# --------------------------------------------------
# Load Environment
# --------------------------------------------------

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")

if not SUPABASE_URL:
    raise Exception("SUPABASE_URL not found in .env")

if not SUPABASE_KEY:
    raise Exception("SUPABASE_SERVICE_ROLE_KEY not found in .env")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

# --------------------------------------------------
# Project Paths
# --------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent

QUESTION_BANK = PROJECT_ROOT / "question_bank"

print("=" * 60)
print("Question Bank Importer")
print("=" * 60)

print("Project :", PROJECT_ROOT)
print("Questions :", QUESTION_BANK)

if not QUESTION_BANK.exists():
    raise Exception(f"Folder not found : {QUESTION_BANK}")

print("Connected to Supabase")
print()
# --------------------------------------------------
# Helper Functions
# --------------------------------------------------

def get_subject(subject_name: str):
    result = (
        supabase.table("subjects")
        .select("*")
        .eq("name", subject_name)
        .execute()
    )

    if result.data:
        print(f"Subject found : {subject_name}")
        return result.data[0]

    created = (
        supabase.table("subjects")
        .insert({"name": subject_name})
        .execute()
    )

    print(f"Subject created : {subject_name}")

    return created.data[0]


def get_chapter(subject_id: str, chapter_name: str):
    result = (
        supabase.table("chapters")
        .select("*")
        .eq("subject_id", subject_id)
        .eq("name", chapter_name)
        .execute()
    )

    if result.data:
        print(f"Chapter found : {chapter_name}")
        return result.data[0]

    created = (
        supabase.table("chapters")
        .insert(
            {
                "subject_id": subject_id,
                "name": chapter_name,
            }
        )
        .execute()
    )

    print(f"Chapter created : {chapter_name}")

    return created.data[0]
    print("\nTesting Subject...")

    # --------------------------------------------------
# Find JSON Files
# --------------------------------------------------
def find_json_files():

    files = sorted(QUESTION_BANK.rglob("*.json"))

    print(f"\nFound {len(files)} JSON files\n")

    for file in files:
        print(file.relative_to(QUESTION_BANK))

    return files

# --------------------------------------------------
# Read JSON
# --------------------------------------------------

def load_json(path: Path):

    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    except Exception as e:
        print(f"\n❌ ERROR : {path}")
        print(e)
        return None



def main():

    files = find_json_files()

    print()

    for file in tqdm(files):

    data = load_json(file)

    if data is None:
        continue

    print(f"\nLoaded : {file.name}")
    print(f"Questions : {len(data['questions'])}")

if __name__ == "__main__":
    main()
json_files = find_json_files()

first = load_json(json_files[0])